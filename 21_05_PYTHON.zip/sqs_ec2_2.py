import boto3  #import library

#regions = ['us-east-1','us-east-2']

#for r  in regions:    
#estalish the connecction from local to AWS EC2 services using IAM credentials
ec2_client = boto3.client('ec2',aws_access_key_id='AKIAXX34JTJJKXGTPEM2',aws_secret_access_key=r'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', region_name='us-east-2')

ec2_client.run_instances(ImageId='ami-05220ffa0e7fce3d1', InstanceType='t2.micro',
                             KeyName = r'C:\Users\welcome\AppData\Local\Programs\Python\Python37-32\test-ec2',
                             MinCount = 1,
                             MaxCount=1)
print('insances created')

