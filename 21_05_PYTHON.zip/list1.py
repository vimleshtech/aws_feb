import threading

def lambda_one():
    for i in range(1,5):
        print(i)
def lambda_two():    
    for i in range(11,15):
        print(i)

p1 = threading.Thread(target=lambda_one,name='processs1')
p2 = threading.Thread(target=lambda_two,name='processs2')
p1.start()
p2.start()


#lambda_one()
#lambda_two()

    
