import boto3
ec2 = boto3.client('ec2',aws_access_key_id='AKIAXX34JTJJKXGTPEM2',aws_secret_access_key=r'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', region_name='us-east-2')

key_name ='ec2-keypair'

try:
    #ec2 = boto3.resource('ec2')

    # create a file to store the key locally
    outfile = open(key_name+'.pem','w')

    # call the boto ec2 function to create a key pair
    key_pair = ec2.create_key_pair(KeyName='ec2-keypair')

    print(key_pair )

    # capture the key and store it in a file
    #KeyPairOut = str(key_pair.key_material)

    #print(KeyPairOut)
    #outfile.write(KeyPairOut)
except:
    pass


ec2_client = boto3.client('ec2',aws_access_key_id='AKIAXX34JTJJKXGTPEM2',aws_secret_access_key=r'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', region_name='us-east-2')

ec2_client.run_instances(ImageId='ami-05220ffa0e7fce3d1', InstanceType='t2.micro',
                             KeyName = key_name,
                             MinCount = 1,
                             MaxCount=1)
print('insances created')






