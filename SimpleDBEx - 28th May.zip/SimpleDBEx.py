import boto3

domain = "TEST_DOMAIN"
reg='us-east-1'
aws_key_id='AKIATOQWG7QP62CTB55S'
aws_secret_key='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'
    
sdb = boto3.client('sdb',
                   aws_access_key_id=aws_key_id,
                   aws_secret_access_key=aws_secret_key,
                   region_name=reg)
#print(sdb) #check connection 

#create domain 
#res = sdb.create_domain(DomainName=domain)
#print(res)

#get list of domain 
response = sdb.list_domains()
#print('Domain List :',response)


def save_data(sdb,domain,key,val):
     sdb.put_attributes(DomainName=domain,
                       ItemName=key,
                       Attributes=[
                       {
                          'Name': 'color',
                          'Value': val,
                          'Replace': True
                      },
                       ],
                   )

#save data in domain
'''
for i in range(0,3):
     key = input('enter key :')
     val = input('enter data :')
     save_data(sdb,domain,key,val)
'''


     

r =sdb.select(SelectExpression='select * from '+ domain)
#print(r)

out = r['Items']
for r in out:
     print(r)
     





     
     


    









